# Notion calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/kkurakkura321/pen/gONmMax](https://codepen.io/kkurakkura321/pen/gONmMax).

